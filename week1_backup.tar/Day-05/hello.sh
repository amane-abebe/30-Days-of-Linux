echo 'hello you successfully run this script.'
